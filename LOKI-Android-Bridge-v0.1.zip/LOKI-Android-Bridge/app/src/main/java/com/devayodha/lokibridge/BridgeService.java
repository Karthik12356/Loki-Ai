package com.devayodha.lokibridge;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import rikka.shizuku.Shizuku;

public class BridgeService extends Service {
    static final int PORT = 8765;
    ServerSocket server;
    Thread thread;

    @Override public void onCreate() {
        super.onCreate();
        startForeground(42, notification());
        thread = new Thread(() -> {
            try { server = new ServerSocket(PORT, 16, InetAddress.getByName("127.0.0.1"));
                while (!Thread.currentThread().isInterrupted()) handle(server.accept());
            } catch (Exception ignored) {}
        }, "loki-http"); thread.start();
    }

    Notification notification() {
        String ch="loki_bridge"; NotificationManager nm=getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"LOKI Bridge",NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this,ch).setContentTitle("LOKI Bridge").setContentText("Listening on localhost:8765").setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).build();
    }

    void handle(Socket s) {
        try (Socket sock=s; BufferedReader in=new BufferedReader(new InputStreamReader(sock.getInputStream(), StandardCharsets.UTF_8)); OutputStream out=sock.getOutputStream()) {
            String line=in.readLine(); if(line==null)return; String[] p=line.split(" "); String method=p[0], path=p[1]; int len=0;
            while(!(line=in.readLine()).isEmpty()) if(line.toLowerCase().startsWith("content-length:")) len=Integer.parseInt(line.split(":",2)[1].trim());
            char[] body=new char[len]; if(len>0) in.read(body); String json=new String(body);
            String result;
            if(method.equals("OPTIONS")) result="{\"ok\":true}";
            else if(path.equals("/health")) result=health();
            else if(path.equals("/command") && method.equals("POST")) result=command(extract(json,"command"));
            else result="{\"ok\":false,\"error\":\"not_found\"}";
            byte[] data=result.getBytes(StandardCharsets.UTF_8);
            String h="HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Content-Type\r\nAccess-Control-Allow-Methods: GET,POST,OPTIONS\r\nContent-Length: "+data.length+"\r\nConnection: close\r\n\r\n";
            out.write(h.getBytes(StandardCharsets.UTF_8)); out.write(data); out.flush();
        } catch(Exception ignored){}
    }

    String health(){ boolean b=Shizuku.pingBinder(); boolean perm=false; try{perm=Shizuku.checkSelfPermission()==android.content.pm.PackageManager.PERMISSION_GRANTED;}catch(Throwable ignored){} return "{\"ok\":true,\"shizuku\":"+b+",\"permission\":"+perm+"}"; }
    String command(String c){
        if(c==null)c=""; c=c.toLowerCase().trim();
        if(!Shizuku.pingBinder()) return err("shizuku_offline");
        try{ if(Shizuku.checkSelfPermission()!=android.content.pm.PackageManager.PERMISSION_GRANTED) return err("shizuku_permission_required"); }catch(Throwable t){return err("permission_check_failed");}
        String cmd=null;
        if(c.equals("open_youtube")) cmd="monkey -p com.google.android.youtube 1";
        else if(c.equals("open_whatsapp")) cmd="monkey -p com.whatsapp 1";
        else if(c.equals("open_settings")) cmd="am start -a android.settings.SETTINGS";
        else if(c.equals("open_bluetooth")) cmd="am start -a android.settings.BLUETOOTH_SETTINGS";
        else if(c.equals("home")) cmd="input keyevent 3";
        else if(c.equals("recents")) cmd="input keyevent 187";
        else if(c.equals("lock")) cmd="input keyevent 26";
        else return err("unsupported_command");
        try{
            Process p=Shizuku.newProcess(new String[]{"sh","-c",cmd},null,null);
            int code=p.waitFor(); return "{\"ok\":"+(code==0)+",\"command\":\""+esc(c)+"\",\"exit\":"+code+"}";
        }catch(Throwable t){ return err("execution_failed"); }
    }
    String extract(String j,String k){ String needle="\""+k+"\""; int i=j.indexOf(needle); if(i<0)return null; i=j.indexOf(':',i); if(i<0)return null; i++; while(i<j.length()&&Character.isWhitespace(j.charAt(i)))i++; if(i<j.length()&&j.charAt(i)=='\"'){int e=j.indexOf('"',i+1); return e>i?j.substring(i+1,e):null;} return null; }
    String err(String e){return "{\"ok\":false,\"error\":\""+esc(e)+"\"}";} String esc(String s){return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"");}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){try{if(server!=null)server.close();}catch(Exception ignored){} if(thread!=null)thread.interrupt(); super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
