package com.devayodha.lokibridge;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    static final int REQ = 1001;
    TextView status;
    final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode == REQ) updateStatus();
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        status = new TextView(this); status.setTextSize(16); status.setPadding(40,40,40,40);
        setContentView(status);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        startService(new Intent(this, BridgeService.class));
        updateStatus();
    }

    void updateStatus() {
        boolean running = Shizuku.pingBinder();
        String s = "LOKI Bridge\n\nLocal endpoint: http://127.0.0.1:8765\nShizuku binder: " + (running ? "ONLINE" : "OFFLINE");
        if (running) {
            try {
                if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    s += "\nPermission: NOT GRANTED\n\nTap below to authorize.";
                    Button btn = new Button(this); btn.setText("AUTHORIZE SHIZUKU");
                    LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.addView(status); box.addView(btn); setContentView(box);
                    btn.setOnClickListener(v -> Shizuku.requestPermission(REQ)); return;
                } else s += "\nPermission: GRANTED";
            } catch (Throwable t) { s += "\nPermission: CHECK ERROR"; }
        }
        status.setText(s + "\n\nKeep this app running while using LOKI.");
    }

    @Override protected void onDestroy() { Shizuku.removeRequestPermissionResultListener(permissionListener); super.onDestroy(); }
}
