# LOKI Android Bridge v0.1

This is the first native bridge layer for LOKI. It exposes a localhost-only HTTP endpoint at `http://127.0.0.1:8765` and uses Shizuku to execute a small allowlisted command set.

## Current commands
- `open_youtube`
- `open_whatsapp`
- `open_settings`
- `open_bluetooth`
- `home`
- `recents`
- `lock`

## Important
- Shizuku must already be running and authorized for LOKI Bridge.
- The bridge listens only on `127.0.0.1`, not the LAN.
- This first version intentionally uses an allowlist; it does not accept arbitrary shell commands from LOKI.
- `Shizuku.newProcess` is used for this prototype. Current Shizuku documentation recommends moving new integrations toward UserService; the next version should migrate the execution layer to UserService.

## LOKI browser integration
POST JSON to `/command`, for example:
`{"command":"open_youtube"}`

GET `/health` returns Shizuku and permission status.
